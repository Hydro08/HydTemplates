/* The user, sign out and verifySession() live in session.js; the menu in menu.js. The account must be verified to enter this page.
   One page, five views (Dashboard, Enrollment, Schedule, Grades, Calendar events) chosen by the #hash in the menu links. */
document.getElementById("year").textContent = new Date().getFullYear();

verifySession().then(u => {
  if (u && !u.verified) location.replace("profile.html");
});

/* ---------- Views ---------- */
const VIEWS = ["dashboard", "enrollment", "schedule", "grades", "calendar"];
const TITLES = { dashboard: "Dashboard", enrollment: "Enrollment", schedule: "Schedule", grades: "Grades", calendar: "Calendar events" };

function showView() {
  let v = location.hash.slice(1);
  if (!VIEWS.includes(v)) v = "dashboard";
  VIEWS.forEach(id => { document.getElementById(id).hidden = id !== v; });
  document.querySelectorAll("#sideMenu a[data-view]").forEach(a => {
    if (a.dataset.view === v) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
  });
  document.title = `${TITLES[v]} | School Portal`;
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", showView);
showView();

/* ---------- Sample data. Replace it with fetch(API_BASE_URL + "/schedule") etc. once you add the endpoints. ---------- */
const schedule = [
  { subject: "Mathematics", day: "Mon / Wed", time: "8:00 - 9:30 AM", room: "Room 101" },
  { subject: "English", day: "Tue / Thu", time: "9:30 - 11:00 AM", room: "Room 204" },
  { subject: "Science", day: "Mon / Wed", time: "1:00 - 2:30 PM", room: "Lab 2" },
  { subject: "Computer Programming", day: "Fri", time: "8:00 - 11:00 AM", room: "Comp Lab" }
];

const grades = [
  { course: "Mathematics", prelim: 88, midterm: 90, final: 91 },
  { course: "English", prelim: 85, midterm: 87, final: 89 },
  { course: "Science", prelim: 90, midterm: 92, final: 94 },
  { course: "Computer Programming", prelim: 95, midterm: 96, final: 97 }
];

const enrollSteps = [
  { title: "Report card", text: "Submit a copy of your report card to the registrar.", done: true },
  { title: "Valid ID", text: "Bring one valid ID for verification.", done: true },
  { title: "Tuition and fees", text: "Settle your balance at the cashier.", done: false }
];

const daysFromToday = n => { const d = new Date(); d.setDate(d.getDate() + n); return d; };
const events = [
  { date: daysFromToday(3),  title: "Midterm exams begin",    time: "8:00 AM",  place: "All rooms" },
  { date: daysFromToday(9),  title: "Parent-teacher meeting", time: "1:00 PM",  place: "Gymnasium" },
  { date: daysFromToday(15), title: "Science fair",           time: "9:00 AM",  place: "Main hall" },
  { date: daysFromToday(24), title: "Intramurals opening",    time: "7:30 AM",  place: "Oval" }
];

/* ---------- Render ---------- */
document.getElementById("scheduleBody").innerHTML = schedule.map(s => `
  <tr>
    <td data-label="Subject">
      <button type="button" class="subject-toggle" aria-expanded="false">
        <span>${escapeHtml(s.subject)}</span>
      </button>
    </td>
    <td data-label="Day" class="detail">${escapeHtml(s.day)}</td>
    <td data-label="Time" class="detail">${escapeHtml(s.time)}</td>
    <td data-label="Room" class="detail">${escapeHtml(s.room)}</td>
  </tr>`).join("");

document.getElementById("gradesBody").innerHTML = grades.map(g => `
  <tr>
    <td data-label="Course">${escapeHtml(g.course)}</td>
    <td data-label="Prelim">${g.prelim}</td>
    <td data-label="Midterm">${g.midterm}</td>
    <td data-label="Final">${g.final}</td>
    <td data-label="Remarks">${g.final >= 75 ? "Passed" : "Failed"}</td>
  </tr>`).join("");

document.getElementById("enrollId").textContent = user.studentId || "-";
const y = new Date().getFullYear();
document.getElementById("enrollYear").textContent = `${y} - ${y + 1}`;
document.getElementById("enrollSteps").innerHTML = enrollSteps.map(s => `
  <li class="card">
    <h3>${escapeHtml(s.title)} <span class="badge ${s.done ? "ready" : "progress"}">${s.done ? "Done" : "Pending"}</span></h3>
    <p class="muted">${escapeHtml(s.text)}</p>
  </li>`).join("");

document.getElementById("eventsList").innerHTML = events.map(ev => `
  <li class="event">
    <time class="event-date" datetime="${ev.date.toISOString().slice(0, 10)}">
      <span>${ev.date.toLocaleString("en", { month: "short" })}</span>
      <strong>${ev.date.getDate()}</strong>
    </time>
    <div>
      <h3>${escapeHtml(ev.title)}</h3>
      <p class="muted">${escapeHtml(ev.time)} &middot; ${escapeHtml(ev.place)}</p>
    </div>
  </li>`).join("");

/* Phones only: the schedule shows just the subjects; tap one to reveal its day, time and room.
   On larger screens it stays a normal table and the subject is not clickable. */
const phone = window.matchMedia("(max-width: 640px)");
const toggles = document.querySelectorAll(".subject-toggle");

toggles.forEach(btn => {
  btn.addEventListener("click", () => {
    if (!phone.matches) return;
    const row = btn.closest("tr");
    const open = row.classList.toggle("open");
    btn.setAttribute("aria-expanded", open);
  });
});

function syncToggles() {
  toggles.forEach(btn => {
    btn.tabIndex = phone.matches ? 0 : -1;
    if (!phone.matches) {
      btn.closest("tr").classList.remove("open");
      btn.setAttribute("aria-expanded", "false");
    }
  });
}
phone.addEventListener("change", syncToggles);
syncToggles();
