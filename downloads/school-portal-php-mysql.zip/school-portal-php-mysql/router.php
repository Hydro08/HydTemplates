<?php
/**
 * For PHP's built-in server:
 *   php -S localhost:8000 router.php
 * Maps /api/login -> api/login.php, and blocks the database and config files.
 */
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

if (preg_match('#\.(db|sqlite3?|sql)$#i', $path) || preg_match('#(^|/)(config|database|data)/#', $path)) {
    http_response_code(403);
    echo 'Forbidden';
    return true;
}

if (preg_match('#^/api/([a-z-]+)$#', $path, $m)) {
    $file = __DIR__ . '/api/' . $m[1] . '.php';
    if (is_file($file)) {
        require $file;
        return true;
    }
    http_response_code(404);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['message' => 'Not found.']);
    return true;
}

return false; // let the built-in server handle the other files (html, css, js)
