<?php
declare(strict_types=1);

/**
 * Connects to MySQL / MariaDB (XAMPP, Laragon, ...). Settings are in config/config.php
 * (or the environment variables DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS).
 *
 * The database and its tables are created automatically when they do not exist yet
 * (the MySQL user needs permission to create a database; XAMPP root has it).
 * Databases made by older versions of this template are upgraded automatically (see "Migrations").
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $c = require __DIR__ . '/config.php';
    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,   // real prepared statements (numbers stay numbers)
    ];
    $dsn = "mysql:host={$c['host']};port={$c['port']};charset=utf8mb4";

    try {
        $pdo = new PDO("$dsn;dbname={$c['name']}", $c['user'], $c['pass'], $opts);
    } catch (PDOException $e) {
        // 1049 = unknown database: create it, then connect again
        if ((int)($e->errorInfo[1] ?? 0) !== 1049 || !preg_match('/^[A-Za-z0-9_]+$/', $c['name'])) {
            error_log($e->getMessage());
            respond(500, ['message' => 'Cannot connect to the database. Check config/config.php and that MySQL is running.']);
        }
        try {
            $root = new PDO($dsn, $c['user'], $c['pass'], $opts);
            $root->exec("CREATE DATABASE IF NOT EXISTS `{$c['name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo = new PDO("$dsn;dbname={$c['name']}", $c['user'], $c['pass'], $opts);
        } catch (PDOException $e2) {
            error_log($e2->getMessage());
            respond(500, ['message' => 'Cannot create the database. Create "' . $c['name'] . '" in phpMyAdmin.']);
        }
    }

    // Create the tables when they do not exist yet: one statement at a time (comment lines are dropped first).
    $schema = preg_replace('/^\s*--.*$/m', '', (string)file_get_contents(__DIR__ . '/../database/schema.sql'));
    foreach (array_filter(array_map('trim', explode(';', (string)$schema))) as $sql) {
        $pdo->exec($sql);
    }

    // --- Migrations for databases created by older versions of this template ---
    // users.student_id: add the column to an old users table
    $hasStudentId = $pdo->query("SHOW COLUMNS FROM users LIKE 'student_id'")->fetch();
    if (!$hasStudentId) {
        $pdo->exec('ALTER TABLE users ADD COLUMN student_id VARCHAR(30) NULL AFTER username, ADD UNIQUE KEY users_student_id_uq (student_id)');
    }
    // Old profiles had a Student ID typed by the user. It now lives in users.student_id (assigned automatically):
    // keep the IDs people already have, then drop the old column.
    $oldProfileId = $pdo->query("SHOW COLUMNS FROM profiles LIKE 'student_id'")->fetch();
    if ($oldProfileId) {
        $pdo->exec('UPDATE users u JOIN profiles p ON p.user_id = u.id SET u.student_id = p.student_id WHERE u.student_id IS NULL');
        $pdo->exec('ALTER TABLE profiles DROP COLUMN student_id');
    }

    return $pdo;
}
