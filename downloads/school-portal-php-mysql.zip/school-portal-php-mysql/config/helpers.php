<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

function respond(int $status, array $data): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Only allows the right HTTP method. For POST, only JSON is accepted (protects against CSRF). */
function require_method(string $method): void
{
    if ($_SERVER['REQUEST_METHOD'] !== $method) {
        header('Allow: ' . $method);
        respond(405, ['message' => 'This method is not allowed.']);
    }
    if ($method === 'POST') {
        $type = strtolower($_SERVER['CONTENT_TYPE'] ?? '');
        if (strpos($type, 'application/json') === false) {
            respond(415, ['message' => 'Only JSON is accepted.']);
        }
    }
}

function json_body(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw === false ? '' : $raw, true);
    return is_array($data) ? $data : [];
}

function start_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
            'secure'   => !empty($_SERVER['HTTPS']),
        ]);
        session_start();
    }
}

/** Password rules (same as the sign up form): 8+ characters, an uppercase letter, a number and a special character.
 *  Returns a message, or null if the password is fine. */
function password_problem(string $password): ?string
{
    $missing = [];
    if (strlen($password) < 8) { $missing[] = 'at least 8 characters'; }
    if (!preg_match('/[A-Z]/', $password)) { $missing[] = 'an uppercase letter'; }
    if (!preg_match('/[0-9]/', $password)) { $missing[] = 'a number'; }
    if (!preg_match('/[^\p{L}\p{N}\s]/u', $password)) { $missing[] = 'a special character'; }
    if ($missing) { return 'Password needs ' . implode(', ', $missing) . '.'; }
    if (strlen($password) > 72) { return 'The password is too long (max 72).'; }   // bcrypt only uses the first 72 bytes
    return null;
}

/** Requires a signed-in user. Returns the user id, or responds 401 if there is none. */
function require_user(): int
{
    start_session();
    if (empty($_SESSION['uid'])) {
        respond(401, ['message' => 'You are not signed in.']);
    }
    return (int)$_SESSION['uid'];
}

/** An account is verified when it has a complete profile (config/db.php must be loaded). */
function is_verified(int $uid): bool
{
    $stmt = db()->prepare('SELECT 1 FROM profiles WHERE user_id = :id');
    $stmt->execute([':id' => $uid]);
    return (bool)$stmt->fetchColumn();
}

/**
 * Use this in endpoints that are for verified users only (e.g. schedule, grades):
 *   $uid = require_verified();
 */
function require_verified(): int
{
    $uid = require_user();
    if (!is_verified($uid)) {
        respond(403, ['message' => 'Complete your profile first to verify your account.', 'verified' => false]);
    }
    return $uid;
}

/**
 * STUDENT ID: how IDs are made is up to you (the school). This template just hands out a random one when
 * the account is created: the current year + 5 random digits, e.g. 2026-48213.
 * Replace this function with your own rule (sequential numbers, a school-issued list, a course prefix, ...).
 * Keep it unique: users.student_id has a unique index.
 */
function random_student_id(): string
{
    return date('Y') . '-' . str_pad((string)random_int(0, 99999), 5, '0', STR_PAD_LEFT);
}

/** Returns the user's Student ID. Creates one if the user does not have it yet (e.g. accounts made before this feature). */
function ensure_student_id(int $uid): string
{
    $stmt = db()->prepare('SELECT student_id FROM users WHERE id = :id');
    $stmt->execute([':id' => $uid]);
    $current = $stmt->fetchColumn();
    $stmt->closeCursor();
    if (is_string($current) && $current !== '') {
        return $current;
    }
    for ($i = 0; $i < 20; $i++) {
        try {
            $set = db()->prepare('UPDATE users SET student_id = :s WHERE id = :id AND student_id IS NULL');
            $set->execute([':s' => random_student_id(), ':id' => $uid]);
            break;
        } catch (PDOException $e) {
            if ($e->getCode() !== '23000') {
                throw $e;
            }
            // that random ID is already taken: try another one
        }
    }
    $stmt->execute([':id' => $uid]);
    return (string)$stmt->fetchColumn();
}
