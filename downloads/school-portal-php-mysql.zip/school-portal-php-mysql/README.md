# PHP + MySQL backend

A small backend with sign up, sign in, the **school portal profile** and the **chat** of the quiz app (student <-> teacher messages).
It has the same folders and style as `php-sqlite`, but it saves everything in MySQL / MariaDB.

Endpoints (JSON). The chat ones are described in [`../CHAT-API.md`](../CHAT-API.md).

| Method | Path          | Body                                   | Response                                          |
|--------|---------------|----------------------------------------|---------------------------------------------------|
| POST   | /api/register | name, username, password               | 201 {student_id} / 409 (username already taken)   |
| POST   | /api/login    | username, password                     | 200 {name, username, verified, student_id} / 401  |
| GET    | /api/me       |                                        | 200 {name, username, verified, student_id} / 401  |
| GET    | /api/profile  |                                        | 200 {verified, profile, student_id} / 401         |
| POST   | /api/profile  | the 16 profile fields (see below)      | 200 / 422 {field, message}                        |
| POST   | /api/change-password | current_password, new_password   | 200 / 403 (wrong current password) / 422          |
| POST   | /api/logout   |                                        | 200                                               |
| GET    | /api/chats    |                                        | 200 {chats}                                       |
| GET    | /api/messages | ?with=username&after=id                | 200 {messages}                                    |
| POST   | /api/messages | to, text                               | 201 {message} / 403 / 404 / 422 / 429             |
| POST   | /api/markread | with                                   | 200 {updated}                                     |
| GET    | /api/unread   |                                        | 200 {count, by_user}                              |

## How to run (XAMPP)

1. Start **Apache** and **MySQL** in the XAMPP Control Panel.
2. Put this folder in `htdocs` (for example `htdocs/school-portal`) and open http://localhost/school-portal/
   (`DEMO_MODE` is already `false` in `shared/js/config.js` of the downloaded zip).
3. The database `hyd_app` and its tables are created automatically on the first request.

`API_BASE_URL` in `shared/js/config.js` is `/api`. That only works when the project is at the root of the server.
If you use `htdocs/school-portal`, change it to `/school-portal/api`.
The `.htaccess` maps `/api/login` to `api/login.php`. (Apache needs `AllowOverride All` for that; XAMPP already has it.)

Without Apache, use PHP's built-in server (requires PHP 8+ with `pdo_mysql`) and keep `API_BASE_URL = "/api"`:

    cd <project folder>
    php -S localhost:8000 router.php

## Database settings

Edit `config/config.php` (XAMPP default: user `root`, empty password, database `hyd_app`).
You can also use the environment variables `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS`.
If the automatic creation fails, create an empty database with the same name in phpMyAdmin
(`CREATE DATABASE hyd_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`) and reload.

Older databases are upgraded automatically: `users.student_id` is added, and a profile that had a typed Student ID keeps it
(it moves to `users.student_id`).

## Verification (school portal)

An account is **verified** when every required profile field is filled in and valid (there is a row in the `profiles` table).
After signing in, a user who is not verified yet is sent to `profile.html` first and cannot enter the portal until the profile is complete.

Profile fields: `birthdate`, `year_level`, `section`, `email`, `phone`, `street`, `barangay`, `city`, `province`, `zip`,
`father_name`, `father_occupation`, `father_phone`, `mother_name`, `mother_occupation`, `mother_phone`.
The Student ID is not a profile field: it is assigned automatically (see below).

For your own endpoints that only verified users should reach (e.g. schedule, grades), use `require_verified()` from `config/helpers.php`:

    $uid = require_verified(); // 401 if not signed in, 403 if not verified yet

To add or remove a required field, edit `profiles` in `database/schema.sql` (and your existing table), `FIELDS` and `validate_profile()`
in `api/profile.php`, and `profile.html`, `profile.js` and `demo-profile.js` in `frontend/school-portal/`.

## Student ID (you decide)

The Student ID is assigned **automatically and randomly** when an account is created (`2026-48213` = current year + 5 random digits).
Students cannot change it. It is stored in `users.student_id` (unique) and returned by `/api/register`, `/api/login`, `/api/me` and `/api/profile`.
To use your own rule (sequential numbers, a prefix per course, school-issued IDs...), change `random_student_id()` in `config/helpers.php`.
Keep the IDs unique.

## Who may chat with who

`chat_can_talk()` in `config/chat.php` is the one place for that rule. By default any signed in user can write to any user,
because this backend has no roles or classes yet. Add yours before you put it online (see `../CHAT-API.md`).

## Notes

- `config/` and `database/` must not be reachable from the browser. `.htaccess` and `router.php` block them.
- Never use the `root` user with no password on a real server. Create a MySQL user for this database and set `DB_USER` / `DB_PASS`.
- Never put a real database password in the code or in a zip. Use the environment variables.
- Passwords are hashed with `password_hash`. Login uses sessions (httponly cookie).
- There is no rate limiting on login. If you put this online, add a limit for wrong logins.
