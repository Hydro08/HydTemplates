-- Created automatically by config/db.php when the tables do not exist yet.
-- (db.php runs the statements one by one, so every statement must end with a semicolon
-- and no comment may contain one.)
CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(200) NOT NULL,
  username      VARCHAR(50)  NOT NULL,
  student_id    VARCHAR(30)  NULL,                 -- assigned automatically at sign up, see random_student_id() in config/helpers.php
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY users_username_uq (username),         -- utf8mb4_unicode_ci = "Ana" and "ana" are the same username
  UNIQUE KEY users_student_id_uq (student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A user's profile. A row here (all required fields filled in) means the account is verified.
CREATE TABLE IF NOT EXISTS profiles (
  user_id           INT UNSIGNED NOT NULL PRIMARY KEY,
  birthdate         DATE         NOT NULL,
  year_level        VARCHAR(20)  NOT NULL,
  section           VARCHAR(100) NOT NULL,
  email             VARCHAR(200) NOT NULL,
  phone             VARCHAR(20)  NOT NULL,
  street            VARCHAR(150) NOT NULL,
  barangay          VARCHAR(100) NOT NULL,
  city              VARCHAR(100) NOT NULL,
  province          VARCHAR(100) NOT NULL,
  zip               VARCHAR(10)  NOT NULL,
  father_name       VARCHAR(200) NOT NULL,
  father_occupation VARCHAR(100) NOT NULL,
  father_phone      VARCHAR(20)  NOT NULL,
  mother_name       VARCHAR(200) NOT NULL,
  mother_occupation VARCHAR(100) NOT NULL,
  mother_phone      VARCHAR(20)  NOT NULL,
  verified_at       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT profiles_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Chat: messages between two users (see backend/CHAT-API.md). Times are in milliseconds since 1970.
CREATE TABLE IF NOT EXISTS messages (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  sender_id    INT UNSIGNED    NOT NULL,
  recipient_id INT UNSIGNED    NOT NULL,
  body         TEXT            NOT NULL,
  sent_at      BIGINT UNSIGNED NOT NULL,
  read_at      BIGINT UNSIGNED NULL,               -- NULL = the receiver did not read it yet
  KEY messages_pair_idx   (sender_id, recipient_id, id),
  KEY messages_unread_idx (recipient_id, read_at),
  CONSTRAINT messages_sender_fk    FOREIGN KEY (sender_id)    REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT messages_recipient_fk FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
