Quiz App (frontend only, demo)

Open it with a local server (VS Code Live Server, or: python -m http.server 8000).

THREE ROLES
  admin    One account only: admin / admin123. Nobody can sign up as admin.
  teacher  teacher / teacher123 (demo). A new teacher signs up on the sign up page: pick "Teacher" and type the
           TEACHER CODE (demo code: TEACHER1). The admin sees the teacher code on the admin dashboard and can make a new one.
  student  Anyone can sign up as a student. In the demo, any other username and password also signs in as a student
           (a new name becomes a new student account). Demo student: student / student123.
Admin and teacher accounts always need their real password.
To make sign in strict (only existing accounts), set ANY_USER_CAN_SIGN_IN = false at the top of auth.js.

MENU (BURGER BUTTON) - everybody has it, top left. Your name and the color circle are at the top right. Sign out is at the bottom of the menu.
  admin    Dashboard (teacher code + overview), Teachers (list, delete), Students (all students, remove from class, delete), Reports (messages that were reported in the chat)
  teacher  Dashboard (subjects), Requests (retakes and new students, with a red number when someone is waiting), Students (only the students in their class, with a Remove button and a Quizzes On / Allow quizzes button: the teacher decides who may take the quizzes), Messages
  student  Messages, then teachers, subjects and classmates. Each list shows 5, then "See more" opens the full list in the main window.
The menu is hidden during a quiz.

MESSAGES (CHAT) - student <-> teacher, and student <-> classmate (chat.js)
  - The Messages button is in the menu, with a red number for unread messages. The burger button shows the same number
    (and a small pop-up appears when a new message arrives).
  - A student can write to the teachers they joined AND to their classmates (students who share a teacher). A teacher can write only to
    the students in their class. The admin has no chat, but reads the Reports tab.
  - Enter sends, Shift + Enter makes a new line. Up to 500 characters. On a phone you see the people first, then the conversation.
  - THREE DOTS next to every message: React, Reply, Forward, Copy, and Report (a message you received) or Unsend (a message you sent).
  - HOLD a message (about half a second) = the quick reactions bar. Tap the same emoji again to remove it.
  - Reply shows a small quote (tap it to jump to the old message). Forward sends a copy marked "Forwarded".
  - Report: the admin sees it under Reports (red number on the burger button) and can Dismiss it or Remove the message.
  - In this demo the messages and reports are saved in the browser (database.messages and database.reports in db.js), so two tabs of the same browser can talk to each other.
    For real use you need a backend: the basic endpoints are in backend/CHAT-API.md of the template. Replies, reactions, forwarding, unsend and reports
    need a few more fields and endpoints (see "Message fields" in db.js). Only the data functions at the top of chat.js change.

QUIZ ACCESS (who may take the quizzes)
  - Teacher > Students: every student has a "Quizzes: On" button. Press it to turn quizzes off for that student (it becomes "Allow quizzes").
    "Allow quizzes for all" and "Block quizzes for all" change the whole class at once.
  - The setting is per teacher: it only covers the quizzes of the teacher who set it (a student in two classes can be on in one and off in the other).
  - A student with quizzes off still sees the subjects, but the Take quiz button becomes "Quizzes off", and the quiz cannot be started
    (it is checked again when the student presses it). A quiz that is already running is not stopped. New students start with quizzes ON.
  - Saved as student.quizBlockedBy in db.js.

SCORE COLORS (student badge, the teacher's results table, retake requests and the result screen)
  - Red: 74% and below. Orange: 75% to 85%. Green: 86% to 100%. (The percent is rounded first.)
  - Change the limits with SCORE_ORANGE_FROM and SCORE_GREEN_FROM in app.js, and the colors in the "Score colors" part at the end of quiz.css.

CARDS AND EDITING
  - Subjects, categories and quizzes are cards. Press the card to open it (there is no Open button).
  - Teacher: the three vertical dots on a card open Edit / Delete. Edit changes the name (and the time of a quiz).
  - New subject / category / quiz: every box has a label on top (Name, Time (minutes)).
  - Questions also have the three dots: Edit loads the question into the form, then Save changes.
  - Student subject cards say "Teacher: <name>".

TEACHER: Subject > Category > Quiz > add questions, set minutes, see results, reset a student's attempt.
  Each teacher has their own subjects. Every subject has its own class code.
STUDENT: pick a quiz and answer it once, one question at a time (the Next button shows after you pick an answer).
The questions AND the 4 choices of each question are in a random order for every attempt (anti-cheating), and the score still
follows the right choice. Exception: a question that has a choice like "All of the above", "None of the above" or "Both A and B"
keeps its choices in the order the teacher typed (so those choices stay correct). Its questions are still mixed, and the
teacher sees a "Choices keep their order" label on it. Students see the letters A, B, C, D in front of the choices.
Copy/paste is blocked. Leaving the tab cancels the quiz: the student goes back to the list of quizzes with a message and has to start again.

QUIZ RULES BOX
  Floats in the center when a student opens the dashboard. It only closes with "Got it" or "Don't show again"
  (clicking outside the box or pressing Escape does NOT close it; the box shakes instead).
  "Don't show again" is remembered per user. "View quiz rules" at the very bottom of the page opens it again.
  Edit the rules in dashboard.html.

CLASS CODE (like Google Classroom) - one code for EACH SUBJECT
  - Every subject has its own class code (demo code: ABC123). The teacher opens the subject and sees the code at the top,
    above the categories, with a button to make a new one. Students who already joined stay in the subject.
  - A student must type a subject's class code before seeing it. Until then they see "Join your teacher's class".
    The teacher then approves the request (menu tab "Requests"), and only after that the student gets in.
  - SECTIONS: a subject has one or more sections (type them with a comma, like BSIT 2-1, BSIT 2-2). A student sets their
    own section at the top of the first screen. Only students of those sections can join the subject, even with the right code.
    A subject with no sections accepts every section.
  - The demo student is already in the demo subject. Any other student has to type the code.
  - A student can join MORE subjects ("Join another subject" at the bottom of the first screen), also from other teachers.
  - A removed student needs a class code to join again. Their results are kept.

CLOSING A QUIZ
  - Teacher: the three dots of a quiz (or the quiz page) have "Close quiz" / "Reopen quiz" and "Set close date".
  - A closed quiz cannot be started: the student sees "Closed" instead of "Take quiz". A student who already started it may finish.
  - A close date closes the quiz by itself at that time. "Remove date" takes the date away. You can also type it when you edit the quiz.
  - A retake cannot be approved while the quiz is closed. Reopen it first.
  - Saved as quiz.closed and quiz.closeAt in db.js.

RETAKE REQUESTS
  - A student can take each quiz only once. After finishing, the quiz card shows "Request retake".
  - The teacher sees every waiting request in the menu tab "Retake requests" (a red number is on the burger button and on the tab).
    Approve = the old result is deleted and the student can take the quiz again. Deny (red button) = the score stays,
    the student sees "Retake denied" and can press "Request again".

SITE.CONFIG.JS  -  THE PLACE TO CUSTOMIZE (site owner)
  Open frontend/quiz-app/site.config.js. Everything is written there with comments, no other file needs to change:
    title             the big title (Quizzlet)
    colors            starting colors for everybody: background, text, button, link (null = normal color)
    allowColorPicker  true = users can pick their own colors with the circle, false = hide the circle
    presets           the ready-made color sets inside the circle (add, remove, rename)
    backToTemplates   the "Back to templates" button: "auto" (only inside the Hyd Templates site), true, or false
    headerLinks       your own buttons and links beside the title: text, url, style ("button" or "link"), newTab
  The buttons and links are drawn beside the title at the top of the dashboard (site-links.js).

COLORS (THE CIRCLE NEXT TO YOUR NAME)
  Everybody (admin, teacher, student) has a small circle next to their name, top right. Press it to pick FOUR colors:
  background, text, buttons and links (or a ready-made set). The choice is saved in the browser for each username and
  sits on top of the colors in site.config.js. "Reset" goes back to the site.config.js colors. The code is in theme.js.
  Cards, lines and gray text follow the background and text colors. Links follow the button color unless a link color is picked.

BACK BUTTON
  The browser's Back button works inside the dashboard (mouse back button, phone back gesture, Alt+Left):
  it goes to the screen you were on before (for example from Categories back to the dashboard).
  Refreshing the page keeps you on the same screen. During a quiz, Back is blocked.

Each browser TAB has its own sign in (sessionStorage), so you can be a teacher in one tab and a student in another.
You stay signed in after a refresh, but a new tab or a closed tab needs to sign in again. Sign out also ends the session.
The data (subjects, quizzes, class codes, join and retake requests) is shared by all tabs of the same browser.

All data is saved in the browser (localStorage), see db.js. It stays on ONE device: a student on another phone or computer
has their own empty copy, so class codes only work on the same browser. Use a real backend to share data between devices. The anti-cheat is browser-side only, so a determined
user can bypass it. For real exams, move login, answers and scoring to a backend.

FILE GUIDE (frontend/quiz-app)
  index.html      Sign in / sign up page (the glass book)
  auth.js         What the sign in / sign up buttons do
  auth.css        Look of the sign in / sign up page
  toast.js        The small pop-up messages (used by auth.js and app.js)
  dashboard.html  The page after sign in (app.js draws everything inside it)
  app.js          The dashboard: menu, tabs, subjects, categories, quizzes, taking a quiz
  quiz.css        Look of the dashboard and of the typing 3D logo
  site.config.js  YOUR SETTINGS: title, colors, buttons and links beside the title
  site-links.js   Draws the buttons and links beside the title (reads site.config.js)
  logo.js         The typing title (the text comes from site.config.js)
  theme.js        The color circle next to the name (background, text, button and link colors)
  db.js           The demo database (localStorage). Replace it with a backend later.

TIPS
  - Change the logo size / 3D look: see the "Logo" section at the bottom of quiz.css.
  - Change the title, colors, buttons and links: frontend/quiz-app/site.config.js (the normal colors are in shared/css/variable.css)
  - Start over with empty data: change STORAGE_KEY in db.js (or clear the browser's localStorage).
