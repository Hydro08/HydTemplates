# PHP + SQLite backend

Endpoints (JSON):

| Method | Path          | Body                                   | Response                                          |
|--------|---------------|----------------------------------------|---------------------------------------------------|
| POST   | /api/register | name, username, password               | 201 {student_id} / 409 (username already taken)   |
| POST   | /api/login    | username, password                     | 200 {name, username, verified, student_id} / 401  |
| GET    | /api/me       |                                        | 200 {name, username, verified, student_id} / 401  |
| GET    | /api/profile  |                                        | 200 {verified, profile, student_id} / 401         |
| POST   | /api/profile  | the 16 profile fields (see below)      | 200 / 422 {field, message}                        |
| POST   | /api/change-password | current_password, new_password   | 200 / 403 (wrong current password) / 422          |
| POST   | /api/logout   |                                        | 200                                               |
| GET    | /api/chats    |                                        | 200 {chats} (the quiz app chat: see below)        |
| GET    | /api/messages | ?with=username&after=id                | 200 {messages}                                    |
| POST   | /api/messages | to, text                               | 201 {message} / 403 / 404 / 422 / 429             |
| POST   | /api/markread | with                                   | 200 {updated}                                     |
| GET    | /api/unread   |                                        | 200 {count, by_user}                              |

## Chat (student <-> teacher)

The last five endpoints are the messages of the quiz app (`frontend/quiz-app/chat.js`). The table is `messages` in `database/schema.sql`
(created automatically, like the others) and the helpers are in `config/chat.php`.
Full description of every endpoint: [`../CHAT-API.md`](../CHAT-API.md).

**Important:** this backend only has users, not roles or classes. `chat_can_talk()` in `config/chat.php` is the one place where you decide
who may write to who. By default any signed in user can write to any user, so add your class rule there before you put it online.

## Verification

An account is **verified** when every required profile field is filled in and valid (there is a row in the `profiles` table).
After signing in, a user who is not verified yet is sent to `profile.html` first and cannot enter the portal until the profile is complete.

Profile fields: `birthdate`, `year_level`, `section`, `email`, `phone`, `street`, `barangay`, `city`, `province`, `zip`,
`father_name`, `father_occupation`, `father_phone`, `mother_name`, `mother_occupation`, `mother_phone`.
(Age is not stored: it is calculated from the birthdate on the profile page. The Student ID is not a profile field either: see below.)

For your own endpoints that only verified users should reach (e.g. schedule, grades), use `require_verified()` from `config/helpers.php`:

    $uid = require_verified(); // 401 if not signed in, 403 if not verified yet

## Student ID (you decide)

The Student ID is assigned **automatically and randomly** when an account is created (`2026-48213` = current year + 5 random digits).
Students cannot change it. It is stored in `users.student_id` (unique) and returned by `/api/register`, `/api/login`, `/api/me` and `/api/profile`.
Accounts created before this feature get an ID the next time they sign in.

This is only the default. To use your own rule (sequential numbers, a prefix per course, school-issued IDs...), change `random_student_id()` in `config/helpers.php`.
Keep the IDs unique. For demo mode (no backend) the same idea is `generateStudentId()` in `frontend/school-portal/demo-profile.js`.

## Customizing the profile

To add or remove a required field, edit `profiles` in `database/schema.sql`, `FIELDS` and `validate_profile()` in `api/profile.php`,
and `profile.html`, `profile.js` and `demo-profile.js` in `frontend/school-portal/`.

## How to run

Requires PHP 8+ with `pdo_sqlite` (already included in XAMPP).

    cd <project folder>
    php -S localhost:8000 router.php

Open http://localhost:8000. The app creates `data/app.db` and the `users` and `profiles` tables automatically.
Older databases are upgraded automatically: the first version of `profiles` (with `address` and `guardian_*` columns) is kept as `profiles_old_v1` and those users complete the new profile; profiles that had a typed `student_id` keep their profile and their ID is moved to `users.student_id`.

On Apache/XAMPP, put the folder in `htdocs`. The `.htaccess` takes care of `/api/...`.

## Notes

- `data/` must not be reachable from the browser. `.htaccess` and `router.php` block it.
- Do not commit or zip an `app.db` with real data (it is already in `.gitignore`).
- Passwords are hashed with `password_hash`. Login uses sessions (httponly cookie).
- There is no rate limiting. If you put this online, add a limit for wrong logins.
