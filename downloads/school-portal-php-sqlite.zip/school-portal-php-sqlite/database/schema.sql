-- Created automatically by config/db.php when the tables do not exist yet.
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
  student_id    TEXT COLLATE NOCASE,   -- assigned automatically at sign up (unique index is created in config/db.php)
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- A user's profile. A row here (all required fields filled in) means the account is verified.
-- It is a separate table so it also works on an older app.db that already has the users table.
CREATE TABLE IF NOT EXISTS profiles (
  user_id           INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  birthdate         TEXT NOT NULL,
  year_level        TEXT NOT NULL,
  section           TEXT NOT NULL,
  email             TEXT NOT NULL,
  phone             TEXT NOT NULL,
  street            TEXT NOT NULL,
  barangay          TEXT NOT NULL,
  city              TEXT NOT NULL,
  province          TEXT NOT NULL,
  zip               TEXT NOT NULL,
  father_name       TEXT NOT NULL,
  father_occupation TEXT NOT NULL,
  father_phone      TEXT NOT NULL,
  mother_name       TEXT NOT NULL,
  mother_occupation TEXT NOT NULL,
  mother_phone      TEXT NOT NULL,
  verified_at       TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Chat: messages between two users (see backend/CHAT-API.md). Times are in milliseconds since 1970.
CREATE TABLE IF NOT EXISTS messages (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body         TEXT    NOT NULL,
  sent_at      INTEGER NOT NULL,
  read_at      INTEGER            -- NULL = the receiver did not read it yet
);
CREATE INDEX IF NOT EXISTS messages_pair_idx   ON messages(sender_id, recipient_id, id);
CREATE INDEX IF NOT EXISTS messages_unread_idx ON messages(recipient_id, read_at);
