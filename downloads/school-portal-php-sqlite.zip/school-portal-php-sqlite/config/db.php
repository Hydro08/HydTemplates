<?php
declare(strict_types=1);

/**
 * Connects to SQLite. The database file is data/app.db
 * and is created automatically (with its tables) when it does not exist.
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dir = __DIR__ . '/../data';
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }

    $pdo = new PDO('sqlite:' . $dir . '/app.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON');

    // --- Migrations for databases created by older versions of this template ---
    $profileCols = array_column($pdo->query('PRAGMA table_info(profiles)')->fetchAll(), 'name');
    $pendingCopy = false;
    if ($profileCols && !in_array('father_name', $profileCols, true)) {
        // v1 profiles (address + guardian_* columns): keep the old table untouched, users complete the new profile.
        $pdo->exec('ALTER TABLE profiles RENAME TO profiles_old_v1');
    } elseif ($profileCols && in_array('student_id', $profileCols, true)) {
        // v2 profiles had student_id typed by the user. It now lives in users.student_id, so move the rows over below.
        $pdo->exec('ALTER TABLE profiles RENAME TO profiles_v2_tmp');
        $pendingCopy = true;
    }

    $pdo->exec(file_get_contents(__DIR__ . '/../database/schema.sql'));

    // users.student_id: add the column to an old users table, and make sure IDs are unique
    $userCols = array_column($pdo->query('PRAGMA table_info(users)')->fetchAll(), 'name');
    if (!in_array('student_id', $userCols, true)) {
        $pdo->exec('ALTER TABLE users ADD COLUMN student_id TEXT COLLATE NOCASE');
    }
    $pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS users_student_id_uq ON users(student_id)');

    if ($pendingCopy) {
        $pdo->exec('UPDATE users SET student_id = (SELECT p.student_id FROM profiles_v2_tmp p WHERE p.user_id = users.id)
                    WHERE student_id IS NULL AND id IN (SELECT user_id FROM profiles_v2_tmp)');
        $cols = 'user_id, birthdate, year_level, section, email, phone, street, barangay, city, province, zip,
                 father_name, father_occupation, father_phone, mother_name, mother_occupation, mother_phone, verified_at, updated_at';
        $pdo->exec("INSERT INTO profiles ($cols) SELECT $cols FROM profiles_v2_tmp");
        $pdo->exec('DROP TABLE profiles_v2_tmp');
    }

    return $pdo;
}
