School Portal (frontend only)

Open it with a local server (VS Code Live Server, or: python -m http.server 8000).
It runs in DEMO_MODE (shared/js/config.js): any username and password is accepted.

Verification: after signing in or signing up, the user must complete the profile (profile.html) before entering the portal.
In demo mode the profile is saved in the browser's localStorage.

Student ID: generated automatically (random) at sign up. How IDs are made is up to you: see frontend/school-portal/README.md.
Address: Province -> City -> Barangay suggestions from the public PSGC API (PH_API_BASE in shared/js/config.js).

Change the school photo at frontend/school-portal/assets/school-bg.jpg (1920px wide or larger looks best).
